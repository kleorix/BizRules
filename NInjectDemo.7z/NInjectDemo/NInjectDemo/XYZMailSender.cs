﻿using System;

namespace NInjectDemo {
    public class XYZMailSender : IMailSender, IRequiredLogEntity {
        public ILogging Logging { get; set; }

        public XYZMailSender(ILogging logging) {
            Logging = logging;
        }

        public void Send(string toAddress, string subject) {
            Logging.Debug("This is content");
            Console.WriteLine("XYZ Sending mail to [{0}] with subject [{1}]", toAddress, subject);
        }
    }
}
