﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NInjectDemo {
    public class FormHandler {
        private readonly IMailSender m_mailSender;

        public FormHandler(IMailSender mailSender) {
            m_mailSender = mailSender;
        }

        public void Handle(string toAddress) {
            m_mailSender.Send(toAddress,"This is non IoC");
        }
    }
}
