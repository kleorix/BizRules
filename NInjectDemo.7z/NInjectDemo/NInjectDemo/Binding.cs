﻿using Ninject.Modules;

namespace NInjectDemo {
    public class Binding :NinjectModule{
        public override void Load() {
            Bind<IMailSender>().To<XYZMailSender>();
            Bind<ILogging>().To<XYZLog>();
        }
    }
}
