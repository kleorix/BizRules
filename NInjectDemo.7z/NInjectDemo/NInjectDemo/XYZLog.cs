﻿using System;

namespace NInjectDemo {
    public class XYZLog : ILogging {
        public void Debug(string content) {
            Console.WriteLine("XYZ Logging {0}", content);
        }
    }
}
